[center][size=18pt][font=tahoma][b][color=#006666]GrouDocs Assembly 1.0[/color][/b][/font][/size][/center]

[hr]
[img]http://www.smfpersonal.net/famfamfam/page_white_flash.png[/img] [b]Features:[/b]
     This version is only for SMF 2.0.x !!!

     This mod inserts a custom button on your board, it can insert iframe with Document from your GroupDocs account

     The options of this mod are in: [i]Admin -> Modification Settings[/i]

     Copyright 2011 by GroupDocs @ visit [url=http://groupdocs.com]groupdocs.com[/url] for official support. 

[hr]
